package cars;

public class Car {
    public Type type;
    private String engine;
    boolean turboVersion = true;

    @Override
    public String toString() {
        return "Car{" +
                "type=" + type +
                ", engine='" + engine + '\'' +
                ", turboVersion=" + turboVersion +
                '}';
    }

    public void setType(Type type) {
        this.type = type;
    }

    public void setEngine(String engine) {
        this.engine = engine;
    }
    public String getEngine() {
        return engine;
    }

    public void setTurboVersion(boolean turboVersion) {
        this.turboVersion = turboVersion;
    }
    public boolean isTurboVersion() {
        return turboVersion;
    }
    public Type getType() {
        return type;
    }

    public Car(){}

    public Car(Type type){
        this.type = type;
    }


    public Car(Type type, String engine){
        this(type);
        this.engine = engine;
    }

}
