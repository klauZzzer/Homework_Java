package cars;

public enum Type {
    HATCHBACK,
    PICKUP,
    SEDAN,
    SPORT,
    VAN,
    CROSSOVER
}
