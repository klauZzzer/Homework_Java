package cars;

import java.util.Random;

public class Factory {

    public Car createCar() {
        Car car1 = new Car();
        Random rd = new Random();
        int rdNum = rd.nextInt(0, 6);
        Type type = switch (rdNum) {
            case 0 -> Type.HATCHBACK;
            case 1 -> Type.PICKUP;
            case 2 -> Type.SEDAN;
            case 3 -> Type.SPORT;
            case 4 -> Type.VAN;
            default -> Type.CROSSOVER;
        };
        car1.setType(type);
        car1.setEngine(getEngine(type));
        car1.setTurboVersion(isTurbo(car1.getEngine()));
        return car1;
    }

    public String getEngine(Type type) {
        return type == Type.SPORT ? "V12" : "V8";
    }

    public boolean isTurbo(String engine) {
        return engine.equals("V12");
    }
}
