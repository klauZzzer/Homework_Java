import cars.Car;
import cars.Factory;
import cars.Type;

public class Main {
    public static void main(String[] args) {

        Car car = new Car();
        car.type = Type.SEDAN;
        car.setEngine("V8");
        System.out.println(car.getEngine());
        System.out.println(car.isTurboVersion());

        Factory factory = new Factory();
        Car car1 = factory.createCar();
        System.out.println(car1);










    }
}