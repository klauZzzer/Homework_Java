import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        //1

        Scanner sc = new Scanner(System.in);
        System.out.print("Введите первое число - ");
        int num1 = sc.nextInt();
        System.out.print("Введите второе число - ");
        int num2 = sc.nextInt();
        System.out.print("Введите третье число - ");
        int num3 = sc.nextInt();
        System.out.print("Введите четвертое число - ");
        int num4 = sc.nextInt();
        int mul1 = getMul(num1, num2);
        int mul2 = getMul(num1, num2, num3);
        int mul3 = getMul(num1, num2, num3, num4);
        System.out.println("Умножение двух чисел - " + mul1);
        System.out.println("Умножение трех чисел - " + mul2);
        System.out.println("Умножение четырех чисел - " + mul3);

        //2
        //Я списал с интернета, потому что вообще не могу понять как у меня это должно получиться
        //Два дня голову ломал, но не допер. Объяснение в интернете тоже раз 10 перечитал, но все равно не понял.

        System.out.print("Введите число для вычисления факториала - ");
        int factorial = sc.nextInt();
        int fact = getFact(factorial);
        System.out.println("Факториал - " + factorial + " равен - " + fact);

        //1.2

        int[] array = getRandom();
        System.out.println(Arrays.toString(array));
        System.out.println(Arrays.toString(makeArraySort(array)));
        System.out.println(Arrays.toString(makeZeroOddElement(array)));
        System.out.println(Arrays.toString(makeArraySorted(array)));

        //2.2

        String[] strLength = {"ABC", "HOMEWORK", "WASD", "XYZ", "SORRY"};
        System.out.println(Arrays.toString(strLength));
        System.out.println(getMaxLength(strLength));
        System.out.println(getMinLength(strLength));

    }

    //1

    public static int getMul(int num1, int num2) {
        return num1 * num2;
    }

    public static int getMul(int num1, int num2, int num3) {
        return getMul(num1, num2) * num3;
    }

    public static int getMul(int num1, int num2, int num3, int num4) {
        return getMul(num1, num2, num3) * num4;
    }

    //2

    public static int getFact(int factorial) {
        int result;
        if (factorial == 1) {
            return 1;
        }
        result = getFact(factorial - 1) * factorial;
        return result;
    }

    //1.2

    public static int[] getRandom() {
        int[] rdMas = new int[8];
        Random rd = new Random();
        for (int i = 0; i < rdMas.length; i++) {
            rdMas[i] = rd.nextInt(1, 50);
        }
        return rdMas;
    }

    public static int[] makeArraySort(int[] array) {
        Arrays.sort(array);
        return array;
    }

    public static int[] makeZeroOddElement(int[] array) {
        for (int i = 1; i < array.length; i += 2) {
            array[i] = 0;
        }
        return array;
    }

    public static int[] makeArraySorted(int[] array) {
        Arrays.sort(array);
        return array;
    }

    //2.2

    public static String getMaxLength(String[] strLength) {
        String max = strLength[0];
        for (String maxNum : strLength) {
            if (maxNum.length() > max.length()) {
                max = maxNum;
            }
        }
        return max;
    }

    public static String getMinLength(String[] strLength) {
        String min = strLength[0];
        for (String minNum : strLength) {
            if (minNum.length() < min.length()) {
                min = minNum;
            }
        }
        return min;
    }
}
