package car;

public class Car {
    private String brand;
    private String model;
    private String color;
    private boolean turbo;
    private int year;

    public Car(String brand, String model, String color, boolean turbo, int year) {
        this.brand = brand;
        this.model = model;
        this.color = color;
        this.turbo = turbo;
        this.year = year;
    }

    public String toString() {
        return "Brand - " + brand + ". Model - " + model + ". Color - " + color +
                ". Turbo-Version - " + turbo + ". Year of release - " + year;
    }
}
