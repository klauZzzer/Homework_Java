package math;

public class Math {
    private Math() {}

    public static int addAll(int... numbers) {
        int result = 0;
        for (int num : numbers) {
            result += num;
        }
        return result;
    }

    public static int minusAll(int number, int... numbers) {
        for (int num : numbers) {
            number -= num;
        }
        return number;
    }

    public static int multAll(int... numbers) {
        int result = 1;
        for (int num : numbers) {
            result *= num;
        }
        return result;
    }

    public static int[] powAll(int number, int... numbers) {
        int[] results = new int[numbers.length];
        int b = 0;
        for (int num : numbers) {
            int result = 1;
            for (int i = 0; i < num; i++) {
                result *= number;
            }
            results[b] = result;
            b++;
        }
        return results;
    }
}































