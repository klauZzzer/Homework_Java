import car.Car;
import math.Math;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {

        //1

        System.out.println(Math.addAll(10, 15, 20, 25, 30, 35, 40));
        System.out.println(Math.minusAll(100, 15, 30, 5, 25, 20, 4));
        System.out.println(Math.multAll(2, 4, 8, 10));
        System.out.println(Arrays.toString(Math.powAll(2, 2 ,3 ,4 ,5)));

        //2

        Car newCar1 = new Car("Porsche", "Taycan", "Black", true, 2019);
        Car newCar2 = new Car("Mercedes", "S63 AMG", "Black", true, 2013);
        Car newCar3 = new Car("Bugatti", "Chiron", "Blue", true, 2016);
        System.out.println(newCar1);
        System.out.println(newCar2);
        System.out.println(newCar3);

        Car[] cars = new Car[3];
        cars[0] = newCar1;
        cars[1] = newCar2;
        cars[2] = newCar3;
        System.out.println(Arrays.toString(cars));
        //b.append(String.valueOf(a[i]));
        //в этой строчке кода объект становиться строчкой
    }
}