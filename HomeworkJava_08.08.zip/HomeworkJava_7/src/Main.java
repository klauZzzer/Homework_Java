import java.util.Random;
import java.util.Scanner;
import java.util.UUID;

public class Main {
    public static void main(String[] args) {

        //1 char 0 65535 byte -128 127 short -32768 32767

        Random rd = new Random();
        int intRd = rd.nextInt();
        System.out.println("Тип int - " + intRd);
        float floatRd = rd.nextFloat();
        System.out.println("Тип float - " + floatRd);
        double doubleRd = rd.nextDouble();
        System.out.println("Тип double - " + doubleRd);
        long longRd = rd.nextLong();
        System.out.println("Тип long - " + longRd);
        boolean booleanRd = rd.nextBoolean();
        System.out.println("Тип boolean - " + booleanRd);
        int byteInt = rd.nextInt(-128, 127);
        byte byteRd = (byte)byteInt;
        System.out.println("Тип byte - " + byteRd);
        int shortInt = rd.nextInt(-32768, 32767);
        short shortRd = (short)shortInt;
        System.out.println("Тип short - " + shortRd);
        char charInt = (char) rd.nextInt('A','Z' + 1);
        System.out.println("Тип char - " + charInt);

        //1.2

        String stringRd = String.valueOf(intRd);
        String stringRd2 = String.valueOf(floatRd);
        String stringRd3 = String.valueOf((char)(charInt + charInt));
        String stringRd4 = String.valueOf(longRd);
        System.out.println("Строка 1 - " + stringRd + stringRd2 + stringRd3 + stringRd4);

        String strRd = UUID.randomUUID().toString();
        System.out.println("Строка 2 - " + strRd);

        //2

        Scanner sc = new Scanner(System.in);
        System.out.print("Ваше имя - ");
        String userName = sc.nextLine();
        System.out.print("Ваш возраст - ");
        String userYears = sc.nextLine();
        System.out.print("Ваш вес - ");
        String userWeight = sc.nextLine();
        System.out.println("Уважаемый, " + userName + "! В свои " + userYears + " лет Вы для нас дороги, как " + userWeight + " килограмм золота.");

        //3

        System.out.print("Введите первое число - ");
        int num1 = sc.nextInt();
        System.out.print("Введите второе число - ");
        int num2 = sc.nextInt();
        System.out.println("Сложение - " + (num1 + num2));
        System.out.println("Вычитание - " + (num1 - num2));
        System.out.println("Умножение - " + (num1 * num2));
        System.out.println("Деление - " + (num1 / num2));

        //Доп.Задание

        double a = Math.random();
        double b = Math.random();
        System.out.println(a + " и " + b);
        System.out.println("Разница - " + Math.abs(a-b));
        System.out.println("Минимально из двух значений - " + Math.min(a, b));
        System.out.println("Максимальное из двух значений - " + Math.max(a, b));
        Math.pow(a,b * 10);
        System.out.println("Возведение в степень 1 - " + Math.pow(a, b));
        System.out.println("Возведение в степень 2 - " + Math.pow(b, a));












































    }
}