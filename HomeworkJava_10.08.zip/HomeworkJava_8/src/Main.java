import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        //1

        Scanner sc = new Scanner(System.in);
        System.out.print("Укажите любое количество метров - ");
        float num1 = sc.nextFloat();
        System.out.println("Значение в метрах - " + num1);
        System.out.println("Значение в километрах - " + num1 / 1000);
        System.out.println("Значение в милях - " + 0.000621371 * num1);
        System.out.println("Значение в футах - " + 3.28084 * num1);
        System.out.println("Значение в аршинах - " + 0.7112 * num1);

        System.out.println(" ");

        //2 Долго не мог сделать, но вроде получилось.
        // Наверное это проще как-то сделать можно, но у меня только так получилось.

        System.out.print("Введите стоймость покупки - ");
        double price = sc.nextDouble();
        System.out.print("Введите сумму денег, данную покупателем - ");
        double givenMoney = sc.nextDouble();
        double change = givenMoney - price;
        double cent = change % (int) change * 100;
        int x = (int) change;
        int y = (int) cent;
        System.out.println("Сдача - " + x + " рублей и " + y + " копеек.");

        System.out.println(" ");

        //3

        boolean isYearFinished = true;
        boolean isGoodWeather = true;
        boolean hasBoughtRaincoats = true;
        boolean isJimFree = true;
        boolean hasKateComeBack = false;

        boolean travel = isYearFinished && (isGoodWeather && hasBoughtRaincoats) && (isJimFree ^ hasKateComeBack);
        System.out.println("Поход - " + travel);

        System.out.println(" ");

        //4

        System.out.print("Введите любое целое число - ");
        int userNum = sc.nextInt();
        System.out.println("Число после деления на 2 без остатка - " + (userNum>>1));

        System.out.println(" ");

        //Доп.Задание
        //Не очень понял задание и это 100% неправильно, но вдруг.

        int first = 24;
        int second = 21;
        System.out.println(first + " и " + second);
        first = 24 - 3;
        second = 21 + 3;
        System.out.println(first + " и " + second);




















































    }
}