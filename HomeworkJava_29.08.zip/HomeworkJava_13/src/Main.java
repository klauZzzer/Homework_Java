import java.time.LocalDate;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {

        //1

        LocalDate[] date = {
                LocalDate.of(1990, 8, 17),
                LocalDate.of(1998, 1, 10),
                LocalDate.of(2001, 9, 11),
                LocalDate.of(1700, 12, 27),
                LocalDate.of(1870, 10, 21),
                LocalDate.of(1545, 2, 6),
                LocalDate.of(1945, 5, 1),
                LocalDate.of(1939, 11, 15),
        };
        System.out.println(Arrays.toString(getYears(date)));
        System.out.println(Arrays.toString(makeSortedYears(getYears(date))));
        System.out.println(Arrays.toString(getDay(date)));
        System.out.println(Arrays.toString(makeSortedDays(getDay(date))));
    }

    //2

    public static int[] getYears(LocalDate[] date) {
        LocalDate year = LocalDate.of(1, 1, 1);
        int[] years = new int[date.length];
        for (int i = 0; i < date.length; i++) {
            year = date[i];
            years[i] = year.getYear();
        }
        return years;
    }

    public static int[] makeSortedYears(int[] years) {
        for (int i = 1; i < years.length; i++) {
            int x = years[i];
            int j = i;
            while (j > 0 && years[j - 1] > x) {
                years[j] = years[j - 1];
                j--;
            }
            years[j] = x;
        }
        return years;
    }

    public static int[] getDay(LocalDate[] date) {
        LocalDate day = LocalDate.of(1, 1, 1);
        int[] days = new int[date.length];
        for (int i = 0; i < date.length; i++) {
            day = date[i];
            days[i] = day.getDayOfMonth();
        }
        return days;
    }

    public static int[] makeSortedDays(int[] days) {
        for (int i = 1; i < days.length; i++) {
            int x = days[i];
            int j = i;
            while (j > 0 && days[j - 1] > x) {
                days[j] = days[j - 1];
                j--;
            }
            days[j] = x;
        }
        return days;
    }
}