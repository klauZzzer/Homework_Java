import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        //1

        Random rd = new Random();
        int m = rd.nextInt(10, 100);
        int n = rd.nextInt(10, 100);
        System.out.println("Первое - " + m + " и второе - " + n + " числа.");
        if (m > n) {
            System.out.println("Число - " + n + " ближе к 10");
        } else {
            System.out.println("Число - " + m + " ближе к 10");
        }

        //2

        Scanner sc = new Scanner(System.in);
        System.out.print("Введите первое число - ");
        int intSc1 = sc.nextInt();
        System.out.print("Введите второе число - ");
        int intSc2 = sc.nextInt();
        System.out.print("Введите произведение этих чисел - ");
        int answer = sc.nextInt();
        if (answer == intSc1 * intSc2) {
            System.out.println("Вы великий математик!");
        } else {
            System.out.println("Пора взять учебник в руки! Правильный ответ - " + intSc1 * intSc2);
        }

        //3

        System.out.print("Введите год - ");
        int elvis = sc.nextInt();
        System.out.println(elvis < 1935 ? "Элвис еще не родился!" : elvis < 1978 ? "Элвис жив!" : "Элвис навсегда в наших сердцах!");

        //Доп.Задание

        System.out.print("Введите номер дня недели - ");
        int date = sc.nextInt();
        System.out.println(date == 3 ? "Среда" : date == 1 ? "Понедельник" : date == 2 ? "Вторник" : date == 4 ? "Четверг" : date == 5 ? "Пятница" : date == 6 ? "Суббота" : "Воскресенье");
        System.out.println(date == 3 ? "Вы правы! Сегодня 16.08 Среда" : "Вы ошиблись, сегодня Среда");









    }
}