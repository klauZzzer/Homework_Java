import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        //1

        Random rd = new Random();
        double doubleRd1 = rd.nextDouble();
        double doubleRd2 = rd.nextDouble();
        doubleRd1 = Math.abs(doubleRd1 - 10);
        doubleRd2 = Math.abs(doubleRd2 - 10);
        System.out.printf("%.2f", doubleRd1);
        System.out.print(" и ");
        System.out.printf("%.2f", doubleRd2);
        System.out.println();
        System.out.println(doubleRd1 > 10 && doubleRd1 < doubleRd2 ? "Число - " + doubleRd1 + " ближе к 10" :
                (doubleRd2 > 10 && doubleRd2 < doubleRd1 ? "Число - " + doubleRd2 + " ближе к 10" :
                        (doubleRd1 < 10 && doubleRd1 > doubleRd2 ? "Число - " + doubleRd1 + " ближе к 10" :
                                (doubleRd2 < 10 && doubleRd2 > doubleRd1 ? "Число - " + doubleRd2 + " ближе к 10" : "Числа одинаковы")
                        )
                )
        );

        //2

        Scanner sc = new Scanner(System.in);
        System.out.print("Введите первое число - ");
        int intSc1 = sc.nextInt();
        System.out.print("Введите второе число - ");
        int intSc2 = sc.nextInt();
        System.out.print("Введите произведение этих чисел - ");
        int answer = sc.nextInt();
        if (answer == intSc1 * intSc2) {
            System.out.println("Вы великий математик!");
        } else {
            System.out.println("Пора взять учебник в руки! Правильный ответ - " + intSc1 * intSc2);
        }

        //3

        System.out.print("Введите год - ");
        int elvis = sc.nextInt();
        System.out.println(elvis < 1935 ? "Элвис еще не родился!" :
                (elvis < 1978 ? "Элвис жив!" : "Элвис навсегда в наших сердцах!")
        );

        //Доп.Задание

        System.out.print("Введите номер дня недели - ");
        int date = sc.nextInt();
        System.out.println(date == 3 ? "Среда" :
                (date == 1 ? "Понедельник" :
                        (date == 2 ? "Вторник" :
                                (date == 4 ? "Четверг" :
                                        (date == 5 ? "Пятница" :
                                                (date == 6 ? "Суббота" : "Воскресенье")
                                        )
                                )
                        )
                )
        );
        System.out.println(date == 3 ? "Вы правы! Сегодня 16.08 Среда" : "Вы ошиблись, сегодня Среда");









    }
}