package gift;

public enum Gift {
    DONAT_50,
    DONAT_100,
    DONAT_200,
    DONAT_500

}
