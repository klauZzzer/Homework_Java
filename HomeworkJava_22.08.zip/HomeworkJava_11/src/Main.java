import dayofweek.DayOfWeek;

import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        //1

        int sum = 0;
        while (sum < 10000) {
            int friendGift = new Random().nextInt(4);
            sum += switch (friendGift) {
                case 0 -> 50;
                case 1 -> 100;
                case 2 -> 200;
                default -> 500;
            };
            System.out.println("У меня уже " + sum + " баксов из 10.000!");
        }
        System.out.println("Ура, ура! Я уже заказал компьютер, а завтра мы идем пить в самый лучший бар города!");

        //У меня почему-то не получилось с do while, но вроде и так норм.
        //Единственное не понимаю почему мне после каждого доната не пишет сколько уже из 10000
        //Рандом слишком быстро работает?

        //2

        Scanner sc = new Scanner(System.in);
        do {
            int summ = 0;
            System.out.print("Введите первое число - ");
            int first = sc.nextInt();
            System.out.print("Введите второе число - ");
            int second = sc.nextInt();
            for (int i = Math.min(first, second); i <= Math.max(first, second); i += 2) {
                if (i % 2 != 0) {
                    summ += i;
                } else {
                    i--;
                }
                System.out.println(summ);
            }
            System.out.print("Для прекращения программы напишите quit или для продолжение введите любое значение - ");
            String stop = sc.nextLine();
        } while (!"quit".equalsIgnoreCase(sc.nextLine()));

        //3

        System.out.print("Введите название сегодняшнего дня недели - ");
        String day = sc.nextLine();
        for (DayOfWeek dayOfWeek : DayOfWeek.values()) {
            if (dayOfWeek.name().equals(day)) {
                continue;
            }
            System.out.print(dayOfWeek.ordinal() + " " + dayOfWeek.name() + " ");
        }
        System.out.println();

        //Доп.Задание

        Random rd = new Random();
        int elevator = rd.nextInt(0, 35);
        System.out.println("Лифт на - " + elevator + " этаже.");
        System.out.print("Введите номер этажа - ");
        int userFloor = sc.nextInt();
        boolean isUp = elevator < userFloor;
        for (int i = elevator; i != userFloor; i = isUp ? i + 1 : i - 1) {
            System.out.println("Лифт на - " + i + " этаже");
        }
        System.out.println("Лифт на - " + userFloor + " этаже");
    }
}