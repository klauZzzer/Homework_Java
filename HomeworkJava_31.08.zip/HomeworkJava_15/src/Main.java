import java.util.Locale;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        //1

        Scanner sc = new Scanner(System.in);
        System.out.print("Введите первое слово из четного кол-во букв - ");
        String first = sc.nextLine();
        System.out.print("Введите второе слово из четного кол-во букв - ");
        String second = sc.nextLine();
        StringBuilder sb = new StringBuilder(first);
        StringBuilder strb = new StringBuilder(second);
        System.out.println(sb.delete(first.length() / 2, first.length()).append(strb.delete(0, second.length() / 2)));

        //2

        String str = new String("I study Basic Java");
        System.out.println(transformString(str));

        //3

        String yandex = "AAAAAAAABBBCCCCCCDDEF";
        System.out.println(yandex);
       // System.out.println(countOfString(yandex));
        System.out.println(countOfString1(yandex));


    }

    public static String transformString(String str) {
        System.out.println(str.charAt(str.length() - 1));
        System.out.println(str.contains("Java"));
        System.out.println(str.replace("a", "o"));
        System.out.println(str.toUpperCase(Locale.ROOT));
        System.out.println(str.toLowerCase(Locale.ROOT));
        return str.substring(0, 13);
    }

    public static String countOfString(String yandex) {
        StringBuilder countYandex = new StringBuilder();
        for (int i = 1; i < yandex.length(); i++) {
            String a = String.valueOf(yandex.charAt(i));
            String b = String.valueOf(yandex.charAt(i++));
            if (a.equals(b)) {
                while (a.equals(b)) {
                    int temp = 1;
                    countYandex.append(yandex.charAt(i)).append(temp++);
                }
            } else {
                countYandex.append(yandex.charAt(i));
            }
        }
        return yandex = countYandex.toString();
    }

    public static String countOfString1(String yandex) {
        char previous = yandex.charAt(0);
        int temp = 0;
        char[] array = yandex.toCharArray();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < array.length; i++) {
            if (array[i] != previous) {
                String result = "" + previous + (temp != 1 ? temp : "");
                sb.append(result);
                temp = 1;
                previous = array[i];
            } else {
                temp++;
            }
            if (i == array.length - 1) {
                String result = "" + array[i] + (temp != 1 ? temp : "");
                sb.append(result);
            }
        }

        return sb.toString();
    }
}