import java.util.Arrays;

public class Main {
    public static void main(String[] args) {

        //1

        char k = 'А';
        char[][] doubleArray = new char[5][8];
        for (int i = 0; i < doubleArray.length; i++) {
            for (int j = 0; j < doubleArray[i].length; j++) {
                doubleArray[i][j] = k;
                if (doubleArray[i][j] == 'Е') {
                    doubleArray[i][j+1] = 'Ё';
                    j++;
                }
                k++;
                if (k > 'Я' + 1) {
                    doubleArray[i][j] = ' ';
                }
            }
        }
        System.out.println(Arrays.deepToString(doubleArray));
    }
}