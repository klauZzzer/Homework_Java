package play;

public enum Play {
    STONE,
    SHEARS,
    PAPER
}
