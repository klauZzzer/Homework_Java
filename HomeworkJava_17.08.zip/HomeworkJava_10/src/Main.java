import months.Month;
import play.Play;
import wedding.Wedding;

import java.util.Locale;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        //1

        Scanner sc = new Scanner(System.in);
        System.out.print("Введите сколько лет вы в браке - ");
        int intDate = sc.nextInt();
        Wedding date = switch (intDate) {
            case 1 -> Wedding.PAPER_WEDDING;
            case 2 -> Wedding.LEATHER_WEDDING;
            case 3 -> Wedding.LINEN_WEDDING;
            case 4 -> Wedding.WOOD_WEDDING;
            case 5 -> Wedding.CAST_IRON_WEDDING;
            case 6 -> Wedding.COPPER_WEDDING;
            case 7 -> Wedding.TIN_WEDDING;
            case 8 -> Wedding.CHAMOMILE_WEDDING;
            case 9 -> Wedding.STANNIC_WEDDING;
            case 10, 11, 12, 13, 14 -> Wedding.CRYSTAL_WEDDING;
            case 15, 16, 17, 18, 19 -> Wedding.PORCELAIN_WEDDING;
            case 20, 21, 22, 23, 24 -> Wedding.SILVER_WEDDING;
            case 25, 26, 27, 28, 29 -> Wedding.PEARL_WEDDING;
            case 30, 31, 32, 33, 34 -> Wedding.CORAL_WEDDING;
            case 35, 36, 37, 38, 39 -> Wedding.RUBY_WEDDING;
            case 40, 41, 42, 43, 44 -> Wedding.SAPPHIRE_WEDDING;
            case 45, 46, 47, 48, 49 -> Wedding.GOLD_WEDDING;
            default -> null;
        };
        System.out.println(date != null ? "Поздравляю ваша следующая годовщина - " + date : "Неизвестная дата");

        //2

        System.out.println("Камень, Ножницы, Бумага");
        System.out.print("Введите число Камень(1), Ножницы(2) или Бумага(3) - ");
        int userChoice = sc.nextInt();
        int botChoice = new Random().nextInt(Play.values().length);
        switch (botChoice) {
            case 0 -> System.out.println("Программа выбрала - Камень");
            case 1 -> System.out.println("Программа выбрала - Ножницы");
            case 2 -> System.out.println("Программа выбрала - Бумагу");
        }
        System.out.println(userChoice == 1 && botChoice == 0 ? "Ничья!" :
                (userChoice == 1 && botChoice == 1 ? "Вы победили!" :
                        (userChoice == 1 && botChoice == 2 ? "Программа победила!" :
                                (userChoice == 2 && botChoice == 0 ? "Программа победила!" :
                                        (userChoice == 2 && botChoice == 1 ? "Ничья!" :
                                                (userChoice == 2 && botChoice == 2 ? "Вы победили!" :
                                                        (userChoice == 3 && botChoice == 0 ? "Вы победили" :
                                                                (userChoice == 3 && botChoice == 1 ? "Программа победила!" :
                                                                        (userChoice == 3 && botChoice == 2 ? "Ничья!" : "")
                                                                )
                                                        )
                                                )
                                        )
                                )
                        )
                )
        );

        //Доп.Задание

        sc.nextLine();
        System.out.println();

        System.out.print("Введите название месяца - ");
        String monthStr = sc.nextLine();
        Month month = Month.valueOf(monthStr.toUpperCase(Locale.ROOT));
        String season = switch (month) {
            case JANUARY, FEBRUARY, DECEMBER -> "Зима";
            case MAY, MARCH, APRIL -> "Весна";
            case AUGUST, JUNE, JULY -> "Лето";
            case NOVEMBER, SEPTEMBER, OCTOBER -> "Осень";
        };
        System.out.println(season);
    }
}