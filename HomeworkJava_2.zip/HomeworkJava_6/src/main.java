public class main {
    public static void main(String[] args) {
        char as = 'G';
        int ad = 89;
        byte af = 4;
        short ag = 56;
        float ah = 4.7333436f;
        double aj = 4.355453532;
        long ak = 12121L;

        System.out.println("345" + "->" + "3;4;5");


        //1

        int al = 2147483647;
        al = 2147483647 + 1;
        System.out.println( al );

        //2

        int ay = 21;
        double ax = 45.5;
        System.out.println(ay + ax);
        double ac = 66.5;
        System.out.println(ac);

        //3

        char av = 'A';
        System.out.println(av);
        av = 'A' + 1;
        System.out.println(av);
    }
}
